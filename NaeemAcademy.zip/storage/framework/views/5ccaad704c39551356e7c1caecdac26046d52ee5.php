

<?php $__env->startSection('title', 'JST / PST'); ?>

<?php $__env->startSection('breadcrumb-links'); ?>
    <li>
        <a href="<?php echo e(route('admin.jst-pst.subjects')); ?>"><?php echo e('Subjects'); ?></a>
    </li>
    <li>
        <a href="#"><?php echo e($RegisteredSubject['subject']['name']); ?></a>
    </li>
    <li>
        <a href="#"><?php echo e('Topics'); ?></a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <!-- Bordered Table -->
        <div class="col-sm-12">
            <div class="panel panel-default card-view">
                <form action="<?php echo e(route('admin.jst-pst.topics.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="registered_subject_id" value="<?php echo e($RegisteredSubject['id']); ?>">
                    <div class="input-group mb-15">
                        <input type="text" name="title" class="form-control" placeholder="Topic title">
                        <span class="input-group-btn">
                            <button type="submit" class="btn btn-success btn-anim"><i class="icon-rocket"></i><span
                                    class="btn-text">Save</span></button>
                        </span>
                    </div>
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </form>
                <div class="panel-heading">
                    <div class="pull-left">
                        <h6 class="panel-title txt-dark">Topics</h6>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                </div>
                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-wrap">
                            <div class="table-responsive">
                                <table class="table table-striped mb-0">
                                    <thead>
                                        <tr>
                                            <th>Topic</th>
                                            <th class="text-nowrap text-right">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($topic['title']); ?></td>
                                                <td class="text-nowrap text-right">
                                                    <a href="javascript:void(0)" alt="default" data-toggle="modal"
                                                        class="edit" data-toggle="tooltip" data-original-title="Delete"
                                                        data-title="<?php echo e($topic['title']); ?>" data-id="<?php echo e($topic['id']); ?>">
                                                        <i class="fa fa-edit"></i> </a>
                                                    <a href="javascript:void(0)" data-id="<?php echo e($topic['id']); ?>"
                                                        data-toggle="tooltip" data-original-title="Delete" class="delete">
                                                        <i class="fa fa-trash text-danger"></i> </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Bordered Table -->
    </div>

    <div class="modal fade" id="edit-modal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel"
        aria-hidden="true" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h5 class="modal-title" id="editModal">Edit</h5>
                </div>
                <form id="editFormm" action="<?php echo e(route('admin.jst-pst.topics.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="topic_id">
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="control-label mb-10 text-left">Title</label>
                            <input type="text" class="form-control" name="title" value="" placeholder="Topic Title">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" class="btn btn-success" value="Save">
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('links'); ?>
    <!--alerts CSS -->
    <link href="<?php echo e(asset('kenny/vendors/bower_components/sweetalert/dist/sweetalert.css')); ?>" rel="stylesheet"
        type="text/css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <!-- Sweet-Alert  -->
    <script src="<?php echo e(asset('kenny/vendors/bower_components/sweetalert/dist/sweetalert.min.js')); ?>"></script>

    <script type="text/javascript">
        $(".delete").click(function() {
            let id = $(this).data('id');
            swal({
                title: "Are you sure?",
                text: "You will not be able to recover this data!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#fcb03b",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: false
            }, function() {
                window.location.href = "<?php echo e(url('admin/jst-pst/topics/destroy')); ?>/" + id;
            });
        });

        $(".edit").click(function() {
            let id = $(this).data('id');
            let title = $(this).data('title');
            $("#edit-modal [name='topic_id']").val(id);
            $("#edit-modal [name='title']").val(title);
            $("#edit-modal").modal('show');
        });

        $("#editForm").submit(function(e) {
            e.preventDefault();
            let form = $(this);
            formData = form.serialize();
            $.ajax({
                url: "<?php echo e(route('admin.jst-pst.topics.update')); ?>",
                type: "POST",
                data: formData,
                processData: false
            }).done(function(response, textStatus, xmlHttpRequest) {
                console.log(response);
            }).fail(function(xmlHttpRequest, textStatus, error) {
                swal({
                    title: "Error!",
                    text: error,
                    type: "error",
                })
            })
        });
        
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("Layout.Admin.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NaeemAcademy\resources\views/Admin/jstPst/topics/index.blade.php ENDPATH**/ ?>