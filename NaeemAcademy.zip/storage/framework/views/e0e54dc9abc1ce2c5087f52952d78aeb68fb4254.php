

<?php $__env->startSection('content'); ?>

    <div class="row">

        <!-- Bordered Table -->
        <div class="col-sm-12">
            <div class="panel panel-default card-view">
                <div class="panel-heading">
                    <div class="pull-left">
                        <h6 class="panel-title txt-dark">Subjects</h6>
                    </div>
                    <div class="pull-right">
                        <a href="<?php echo e(route('admin.subjects.add')); ?>" class="btn btn-primary btn-sm">New Subject</a>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                </div>
                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-wrap ">
                            <div class="table-responsive">
                                <table class="table table-striped mb-0">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Status</th>
                                            <th class="text-nowrap text-right">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($subject['name']); ?></td>
                                                <td>
                                                    <?php if($subject['status']['id'] == 1): ?>
                                                        <div class="label label-table label-success">Active</div>
                                                    <?php else: ?>
                                                        <div class="label label-table label-danger">Inactive</div>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-nowrap text-right">
                                                    <a href="<?php echo e(route('admin.subjects.edit', $subject['id'])); ?> "
                                                        class="mr-25" data-toggle="tooltip" data-original-title="Edit">
                                                        <i class="fa fa-pencil text-inverse m-r-10"></i> </a>
                                                    <?php if($subject['status']['id'] == 1): ?>
                                                        <a href="<?php echo e(route('admin.subjects.toggle_status', $subject['id'])); ?>"
                                                            class="mr-25" data-toggle="tooltip"
                                                            data-original-title="Inactive">
                                                            <i class="fa fa-ban text-inverse m-r-10"></i> </a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('admin.subjects.toggle_status', $subject['id'])); ?>"
                                                            class="mr-25" data-toggle="tooltip"
                                                            data-original-title="Active">
                                                            <i class="fa fa-check text-inverse m-r-10"></i> </a>
                                                    <?php endif; ?>

                                                    <a href="javascript:void(0)" data-id="<?php echo e($subject['id']); ?>"
                                                        data-toggle="tooltip" data-original-title="Delete" class="delete"> <i
                                                            class="fa fa-trash text-danger"></i> </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Bordered Table -->

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('links'); ?>
    <!--alerts CSS -->
    <link href="<?php echo e(asset('kenny/vendors/bower_components/sweetalert/dist/sweetalert.css')); ?>" rel="stylesheet"
        type="text/css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <!-- Sweet-Alert  -->
    <script src="<?php echo e(asset('kenny/vendors/bower_components/sweetalert/dist/sweetalert.min.js')); ?>"></script>
   
    <script type="text/javascript">
        $(".delete").click(function() {
            let id = $(this).data('id');
            swal({
                title: "Are you sure?",
                text: "You will not be able to recover this data!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#fcb03b",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: false
            }, function() {
                window.location.href = "<?php echo e(url('admin/subjects/destroy')); ?>/"+id;
            });
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("Layout.Admin.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NaeemAcademy\resources\views/Admin/Subject/index.blade.php ENDPATH**/ ?>