<!-- jQuery -->
<script src="../Kenny/vendors/bower_components/jquery/dist/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="../Kenny/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- Data table JavaScript -->
<script src="../Kenny/vendors/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
<script src="../Kenny/dist/js/dataTables-data.js"></script>
<!-- Slimscroll JavaScript -->
<script src="../Kenny/dist/js/jquery.slimscroll.js"></script>

<!-- Fancy Dropdown JS -->
<script src="../Kenny/dist/js/dropdown-bootstrap-extended.js"></script>
<!-- Init JavaScript -->
<script src="../Kenny/dist/js/init.js"></script><?php /**PATH C:\xampp\htdocs\NaeemAcademy\resources\views/Layout/Admin/foot.blade.php ENDPATH**/ ?>