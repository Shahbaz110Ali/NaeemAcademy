<!-- jQuery -->
<script src="<?php echo e(asset('Kenny/vendors/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('Kenny/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<!-- Data table JavaScript -->
<script src="<?php echo e(asset('Kenny/vendors/bower_components/datatables/media/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('Kenny/dist/js/dataTables-data.js')); ?>"></script>
<!-- Toast JS -->
<script src="<?php echo e(asset('Kenny/vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.js')); ?>"></script>
<script src="<?php echo e(asset('Kenny/dist/js/toast-data.js')); ?>"></script>

<!-- Slimscroll JavaScript -->
<script src="<?php echo e(asset('Kenny/dist/js/jquery.slimscroll.js')); ?>"></script>
<!-- Fancy Dropdown JS -->
<script src="<?php echo e(asset('Kenny/dist/js/dropdown-bootstrap-extended.js')); ?>"></script>

<?php echo $__env->yieldPushContent('scripts'); ?>
<!-- Init JavaScript -->
<script src="<?php echo e(asset('Kenny/dist/js/init.js')); ?>"></script>

<script type="text/javascript">
    <?php if(session('toast')): ?>
        toast_notification("<?php echo e(ucFirst(session('toast'))); ?>", "<?php echo e(session('msg')); ?>",
        "<?php echo e(session('toast')); ?>")
    <?php endif; ?>
</script>
<?php /**PATH C:\xampp\htdocs\NaeemAcademy\resources\views/Layout/includes/foot.blade.php ENDPATH**/ ?>