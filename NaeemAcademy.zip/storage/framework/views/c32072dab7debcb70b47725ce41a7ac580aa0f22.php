
<?php $__env->startSection('title', 'JST / PST'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">

        <!-- Bordered Table -->
        <div class="col-sm-12">
            <div class="panel panel-default card-view">
                <div class="panel-heading">
                    <div class="pull-left">
                        <h6 class="panel-title txt-dark">Tests</h6>
                    </div>
                    <div class="pull-right">
                        <a href="<?php echo e(route('admin.jst-pst.tests.add')); ?>" class="btn btn-primary btn-sm">New Test</a>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                </div>
                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-wrap ">
                            <div class="table-responsive">
                                <table class="table table-striped mb-0">
                                    <thead>
                                        <tr>
                                            <th>Test</th>
                                            <th>Subject</th>
                                            <th>Status</th>
                                            <th class="text-nowrap text-right">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Bordered Table -->

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('links'); ?>
    <!--alerts CSS -->
    <link href="<?php echo e(asset('kenny/vendors/bower_components/sweetalert/dist/sweetalert.css')); ?>" rel="stylesheet"
        type="text/css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <!-- Sweet-Alert  -->
    <script src="<?php echo e(asset('kenny/vendors/bower_components/sweetalert/dist/sweetalert.min.js')); ?>"></script>

    <script type="text/javascript">
        $(".delete").click(function() {
            let id = $(this).data('id');
            swal({
                title: "Are you sure?",
                text: "You will not be able to recover this data!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#fcb03b",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: false
            }, function() {
                window.location.href = "<?php echo e(url('admin/departments/destroy')); ?>/" + id;
            });
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("Layout.Admin.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NaeemAcademy\resources\views/Admin/JstPst/tests/index.blade.php ENDPATH**/ ?>