

<?php $__env->startSection('title', 'JST / PST'); ?>

<?php $__env->startSection('breadcrumb-links'); ?>
<li>
    <a href="<?php echo e(route('admin.jst-pst.subjects')); ?>"><?php echo e("Subjects"); ?></a>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">

        <!-- Bordered Table -->
        <div class="col-sm-12">
            <div class="panel panel-default card-view">
                <form action="<?php echo e(route('admin.jst-pst.subjects.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-15">
                        <select name="subject_id" class="form-control">
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subject['id']); ?>"><?php echo e($subject['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="input-group-btn">
                            <button type="submit" class="btn btn-success btn-anim"><i class="icon-rocket"></i><span
                                    class="btn-text">Save</span></button>
                        </span>
                    </div>
                    <?php $__errorArgs = ['subject_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </form>
                <div class="panel-heading">
                    <div class="pull-left">
                        <h6 class="panel-title txt-dark">Subjects</h6>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                </div>
                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-wrap">
                            <div class="table-responsive">
                                <table class="table table-striped mb-0">
                                    <thead>
                                        <tr>
                                            <th>Subject</th>
                                            <th class="text-nowrap text-right">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $RegisteredSubject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><a href="<?php echo e(route('admin.jst-pst.topics', $value['id'])); ?>"><?php echo e($value['subject']['name']); ?></a></td>
                                                <td class="text-nowrap text-right">
                                                    <a href="javascript:void(0)" data-id="<?php echo e($value['id']); ?>"
                                                        data-toggle="tooltip" data-original-title="Delete" class="delete">
                                                        <i class="fa fa-trash text-danger"></i> </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Bordered Table -->

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('links'); ?>
    <!--alerts CSS -->
    <link href="<?php echo e(asset('kenny/vendors/bower_components/sweetalert/dist/sweetalert.css')); ?>" rel="stylesheet"
        type="text/css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <!-- Sweet-Alert  -->
    <script src="<?php echo e(asset('kenny/vendors/bower_components/sweetalert/dist/sweetalert.min.js')); ?>"></script>

    <script type="text/javascript">
        $(".delete").click(function() {
            let id = $(this).data('id');
            swal({
                title: "Are you sure?",
                text: "You will not be able to recover this data!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#fcb03b",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: false
            }, function() {
                window.location.href = "<?php echo e(url('admin/jst-pst/subjects/destroy')); ?>/" + id;
            });
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("Layout.Admin.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NaeemAcademy\resources\views/Admin/JstPst/subjects/index.blade.php ENDPATH**/ ?>